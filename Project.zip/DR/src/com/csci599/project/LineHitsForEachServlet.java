package com.csci599.project;

import java.util.ArrayList;

public class LineHitsForEachServlet {
	public String servletName;
	public ArrayList<Integer> nodesHit;

	public LineHitsForEachServlet() {
		servletName = "";
		nodesHit = new ArrayList<Integer>();
	}
}