package com.csci599.project;

import java.io.IOException;

public class Runner {

	public static void main(String[] args) throws IOException {

		if (args.length < 2) {
			System.out.println("Expected 2 arguments");
			System.out.println("1. Path to class folder");
			System.out
					.println("2. Name of class file (without .class extension)");
			System.exit(0);
		}
		CFG cfg = new CFG();

		String classPath = args[0];
		String className = args[1];

		cfg.cfgMaker(classPath, className);
		System.out.println("Dotty File generated : "+classPath + "Dotty/" + className + "-main"
				+ ".dotty");
	}

}
