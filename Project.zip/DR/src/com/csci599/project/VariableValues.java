package com.csci599.project;

public class VariableValues {
	public String variableName;
	public Object value;
}
